﻿var config = {
    // 图片服务器监听端口
    port: 8080,
    // 根目录
    rootPath : 'F:\\imageServer',
    // 图片服务器中心ip
    centerIP: '127.0.0.1',
    // 图片服务器中心端口
    centerPort: 80
  };
  module.exports = config;