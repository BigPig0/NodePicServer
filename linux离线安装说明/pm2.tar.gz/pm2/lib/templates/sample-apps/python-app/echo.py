#!/usr/bin/python
import time

while 1:
    print("Start : %s" % time.ctime())
    print("second line")
    time.sleep(1)
