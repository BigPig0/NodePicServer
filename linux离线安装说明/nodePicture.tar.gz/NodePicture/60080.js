﻿var config = {
    // 图片服务器监听端口
    port: 60080,
    // 根目录
    rootPath : '/root/ImageServer',
    // 图片服务器中心ip
    centerIP: '127.0.0.1',
    // 图片服务器中心端口
    centerPort: 60070
  };
  module.exports = config;