﻿var config = {
    // 图片服务器监听端口
    port: 60070,
    // 根目录
    rootPath : '/root/NodePicture/web',
  };
  module.exports = config;